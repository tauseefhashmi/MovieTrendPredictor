# Analysis of MovieLens dataset

The dataset [homepage](http://grouplens.org/datasets/movielens/).

NOTE: The script automatically downloads and unzips the dataset.
